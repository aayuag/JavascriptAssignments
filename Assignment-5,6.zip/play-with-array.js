var input=prompt("Enter the array")
var n=prompt("Enter a number")
var arr=input.split(",")

function getEven(arr){
    let temp=[]
    for(let i=0;i<arr.length;i++){
        if(arr[i]%2==0){
            temp.push(arr[i])
        }
    }
    console.log(temp)
}
function multiplyByN(arr,n){
    let temp=[]
    for(let i=0;i<arr.length;i++){
        temp.push(arr[i]*n)
    }
    console.log(temp)
}
function removeelement(arr,n){
    arr.splice(n,1)
    console.log(arr)
}
getEven(arr)
multiplyByN(arr,n)
removeelement(arr,n)