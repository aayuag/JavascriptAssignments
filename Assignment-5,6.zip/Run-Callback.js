let add=(a,b,cb)=>{
    var sum=a+b;
    cb(sum)
}
let cb=(cb)=>{
    console.log(cb)
}
add(3,4,cb)