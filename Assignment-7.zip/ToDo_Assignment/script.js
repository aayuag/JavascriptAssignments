let count=0
function newadd(e) {
    
    let inputValue = document.getElementById("myInput").value;
    
    if (inputValue=="") {
      alert("You must write something!");

    } else {
      document.getElementById("myInput").value = "";
    }

    var p = document.createElement("p");

    p.setAttribute("key",count);

    p.innerText=inputValue;

    p.addEventListener("click",remove)

    count++

    let div=document.getElementById("tasklist")

    div.appendChild(p)
}
function remove(e){
  let div=document.getElementById("tasklist")
  div.removeChild(e.target)
}